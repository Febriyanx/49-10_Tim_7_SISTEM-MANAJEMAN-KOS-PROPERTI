

<?php $__env->startSection('title', 'Form Input'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Form Input Data Staff Housekeeping</h1>

    <?php echo $__env->make('staff._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projectlaravel\resources\views/staff/create.blade.php ENDPATH**/ ?>