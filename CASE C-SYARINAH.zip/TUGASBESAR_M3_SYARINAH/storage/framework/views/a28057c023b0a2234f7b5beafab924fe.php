<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $__env->yieldContent('title'); ?> - Modul Housekeeper</title>

<style>
:root {
    --gelap: #1e293b;
    --teks: #0f172a;
    --teks-muted: #64748b;
    --teks-muted-2: #94a3b8;
    --aksen: #c2410c;
    --aksen-hover: #9a3412;
    --latar: #f8fafc;
    --kartu: #ffffff;
    --border: #e2e8f0;
    --shadow: 0 1px 3px rgba(15, 23, 42, 0.05);
    --radius-kartu: 8px;
    --radius-input: 6px;
    --radius-badge: 4px;
}

* { box-sizing: border-box; }

body {
    font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
    background-color: var(--latar);
    color: var(--gelap);
    margin: 0;
    padding: 24px 16px;
    line-height: 1.5;
}

.wadah {
    max-width: 1080px;
    margin: 0 auto;
}

.header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
    padding: 18px 24px;
    background-color: var(--gelap);
    color: #ffffff;
    border-radius: var(--radius-kartu) var(--radius-kartu) 0 0;
    border-bottom: 3px solid #c2410c;
    box-shadow: var(--shadow);
}

.header h2 {
    margin: 0;
    font-size: 1.15rem;
    font-weight: 700;
}

.header small {
    display: block;
    margin-top: 2px;
    font-size: 0.78rem;
    color: var(--teks-muted-2);
}

nav {
    display: flex;
    gap: 8px;
}

nav a {
    padding: 6px 14px;
    font-size: 0.85rem;
    font-weight: 600;
    color: #e2e8f0;
    text-decoration: none;
    background-color: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: var(--radius-input);
    transition: all 0.15s ease;
}

nav a:hover {
    background-color: rgba(255, 255, 255, 0.18);
    color: #ffffff;
}

.konten {
    padding: 24px;
    background-color: var(--kartu);
    border: 1px solid var(--border);
    border-top: none;
    border-radius: 0 0 var(--radius-kartu) var(--radius-kartu);
    box-shadow: var(--shadow);
}

h1 {
    margin: 0 0 18px;
    font-size: 1.25rem;
    font-weight: 700;
    color: var(--teks);
}

.sukses {
    margin: 0 0 16px;
    padding: 10px 14px;
    font-size: 0.9rem;
    color: #166534;
    background-color: #f0fdf4;
    border: 1px solid #bbf7d0;
    border-radius: var(--radius-input);
}

.pesan {
    margin: 0 0 16px;
    padding: 10px 14px;
    font-size: 0.9rem;
    color: #991b1b;
    background-color: #fee2e2;
    border: 1px solid #fecaca;
    border-left: 3px solid #c2410c;
    border-radius: var(--radius-input);
}

.pesan ul {
    margin: 0;
    padding-left: 18px;
}


.tabel-wrap {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    background-color: var(--kartu);
}

thead th {
    padding: 12px 10px;
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    text-align: left;
    white-space: nowrap;
    color: #ffffff;
    background-color: var(--gelap);
    border-bottom: 3px solid #c2410c;
}

thead th:first-child { border-top-left-radius: var(--radius-input); }
thead th:last-child  { border-top-right-radius: var(--radius-input); }

tbody td {
    padding: 12px 10px;
    font-size: 0.88rem;
    color: var(--teks);
    border-bottom: 1px solid var(--border);
    vertical-align: middle;
}

tbody tr:hover { background-color: var(--latar); }
tbody tr:last-child td { border-bottom: none; }

td[colspan] {
    padding: 28px;
    text-align: center;
    color: var(--teks-muted);
}

.badge {
    display: inline-block;
    padding: 2px 8px;
    font-size: 0.75rem;
    font-weight: 700;
    border-radius: var(--radius-badge);
    border: 1px solid transparent;
    white-space: nowrap;
}

.badge-biru   { background: #e0f2fe; color: #0369a1; border-color: #bae6fd; }
.badge-kuning { background: #fef3c7; color: #92400e; border-color: #fde68a; }
.badge-hijau  { background: #f0fdf4; color: #166534; border-color: #bbf7d0; }
.badge-abu    { background: #f1f5f9; color: #334155; border-color: #cbd5e1; }

.aksi {
    display: flex;
    align-items: center;
    gap: 8px;
}

.aksi form { margin: 0; }

button,
.btn,
.btn-edit,
.btn-hapus,
.btn-simpan,
.btn-batal {
    display: inline-block;
    padding: 6px 12px;
    font-family: inherit;
    font-size: 0.8rem;
    font-weight: 600;
    line-height: 1.4;
    text-decoration: none;
    cursor: pointer;
    border-radius: var(--radius-input);
    border: 1px solid transparent;
    transition: all 0.15s ease;
}

.btn-simpan {
    padding: 10px 20px;
    font-size: 0.9rem;
    color: #ffffff;
    background-color: var(--aksen);
    border-color: var(--aksen);
}
.btn-simpan:hover {
    background-color: var(--aksen-hover);
    border-color: var(--aksen-hover);
}

.btn-batal {
    padding: 10px 20px;
    font-size: 0.9rem;
    color: #334155;
    background-color: #f1f5f9;
    border-color: #cbd5e1;
}
.btn-batal:hover { background-color: #e2e8f0; }

.btn-edit {
    color: #9a3412;
    background-color: #ffedd5;
    border-color: #fed7aa;
}
.btn-edit:hover {
    color: #ffffff;
    background-color: var(--aksen);
    border-color: var(--aksen);
}

.btn-hapus {
    color: #991b1b;
    background-color: #fee2e2;
    border-color: #fecaca;
}
.btn-hapus:hover {
    color: #ffffff;
    background-color: #b91c1c;
    border-color: #b91c1c;
}

.form-staff label {
    display: block;
    margin: 16px 0 6px;
    font-size: 0.85rem;
    font-weight: 600;
    color: var(--teks);
}

.form-staff > label:first-of-type { margin-top: 0; }

.form-staff input[type="text"],
.form-staff select {
    width: 100%;
    padding: 10px 12px;
    font-family: inherit;
    font-size: 0.9rem;
    color: var(--teks);
    background-color: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: var(--radius-input);
    outline: none;
    transition: border-color 0.15s ease, box-shadow 0.15s ease;
}

.form-staff input[type="text"]:focus,
.form-staff select:focus {
    border-color: var(--aksen);
    box-shadow: 0 0 0 3px rgba(194, 65, 12, 0.15);
}

.checkbox-group {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(190px, 1fr));
    gap: 8px;
    padding: 12px;
    background-color: var(--latar);
    border: 1px solid var(--border);
    border-radius: var(--radius-input);
}

.form-staff .checkbox-group label {
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 0;
    font-weight: 400;
    cursor: pointer;
}

.form-staff input[type="checkbox"] {
    width: 16px;
    height: 16px;
    accent-color: var(--aksen);
}

.form-aksi {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-top: 24px;
}

@media (max-width: 768px) {
    body { padding: 12px 8px; }
    .header, .konten { padding: 16px; }
}
</style>
</head>

<body>
<div class="wadah">

    <header class="header">
        <div>
            <h2>🧹 Sistem Manajemen Housekeeping</h2>
            <small>Modul Data Staff Kebersihan</small>
        </div>
        <nav>
            <a href="<?php echo e(route('staff.create')); ?>">Form Input</a>
            <a href="<?php echo e(route('staff.index')); ?>">Tampilan Data</a>
        </nav>
    </header>

    <main class="konten">
        <?php if(session('success')): ?>
            <p class="sukses"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="pesan">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>

</div>
</body>
</html><?php /**PATH C:\Users\ASUS\OneDrive\Documents\GitHub\WAD-RSAA-SYARINAH-102022500215\TUGASBESAR_M3_SYARINAH\resources\views/layouts/app.blade.php ENDPATH**/ ?>