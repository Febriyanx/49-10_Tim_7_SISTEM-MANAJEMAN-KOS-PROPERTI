<?php
    $tugasTerpilih = old('tugas', $staff->tugas ?? []);
?>

<form method="POST"
      class="form-staff"
      action="<?php echo e($staff->exists ? route('staff.update', $staff) : route('staff.store')); ?>">

    <?php echo csrf_field(); ?>
    <?php if($staff->exists): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <label for="nama">Nama Petugas</label>
    <input type="text" id="nama" name="nama"
           value="<?php echo e(old('nama', $staff->nama)); ?>" required>

    <label for="kontak">No. Kontak</label>
    <input type="text" id="kontak" name="kontak"
           value="<?php echo e(old('kontak', $staff->kontak)); ?>" required>

    <label for="area">Area Penanganan</label>
    <select id="area" name="area">
        <?php $__currentLoopData = \App\Models\Staff::AREA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($pilihan); ?>"
                <?php if(old('area', $staff->area ?? 'Lantai 1') === $pilihan): echo 'selected'; endif; ?>>
                <?php echo e($pilihan); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label for="shift">Shift</label>
    <select id="shift" name="shift">
        <?php $__currentLoopData = \App\Models\Staff::SHIFT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($pilihan); ?>"
                <?php if(old('shift', $staff->shift ?? 'Pagi') === $pilihan): echo 'selected'; endif; ?>>
                <?php echo e($pilihan); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label>Tugas Kebersihan Harian</label>
    <div class="checkbox-group">
        <?php $__currentLoopData = \App\Models\Staff::TUGAS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label>
                <input type="checkbox" name="tugas[]" value="<?php echo e($pilihan); ?>"
                    <?php if(in_array($pilihan, $tugasTerpilih, true)): echo 'checked'; endif; ?>>
                <?php echo e($pilihan); ?>

            </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <label for="status">Status</label>
    <select id="status" name="status">
        <?php $__currentLoopData = \App\Models\Staff::STATUS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($pilihan); ?>"
                <?php if(old('status', $staff->status ?? 'Aktif') === $pilihan): echo 'selected'; endif; ?>>
                <?php echo e($pilihan); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <div class="form-aksi">
        <button type="submit" class="btn-simpan"><?php echo e($staff->exists ? 'Update Data' : 'Simpan'); ?></button>

        <?php if($staff->exists): ?>
            <a href="<?php echo e(route('staff.index')); ?>" class="btn-batal">Batal Edit</a>
        <?php endif; ?>
    </div>

</form><?php /**PATH C:\Users\ASUS\OneDrive\Documents\GitHub\WAD-RSAA-SYARINAH-102022500215\TUGASBESAR_M3_SYARINAH\resources\views/staff/_form.blade.php ENDPATH**/ ?>