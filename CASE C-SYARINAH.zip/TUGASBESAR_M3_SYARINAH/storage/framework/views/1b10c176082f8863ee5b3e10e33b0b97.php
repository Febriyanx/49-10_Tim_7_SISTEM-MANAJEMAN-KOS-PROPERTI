

<?php $__env->startSection('title', 'Tampilan Data'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        :root {
            --biru-tua: #1e3a8a;
            --biru: #2563eb;
            --biru-muda: #dbeafe;
            --biru-sangat-muda: #d2d9df;
            --teks: #1e293b;
            --border: #bfdbfe;
            --merah: #dc2626;
        }

        body {
            font-family: "Segoe UI", Arial, sans-serif;
            background-color: var(--biru-sangat-muda);
            color: var(--teks);
            margin: 0;
            padding: 24px;
        }

        h1 {
            color: var(--biru-tua);
            font-size: 1.6rem;
            margin-bottom: 16px;
            padding-bottom: 8px;
            border-bottom: 3px solid var(--biru);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #ffffff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.15);
        }

        thead {
            background-color: var(--biru);
            color: #170202;
        }

        th,
        td {
            padding: 12px 14px;
            text-align: left;
            font-size: 0.92rem;
        }

        th {
            font-weight: 600;
            white-space: nowrap;
        }

        tbody tr {
            border-bottom: 1px solid var(--border);
            transition: background-color 0.15s ease;
        }

        tbody tr:nth-child(even) {
            background-color: var(--biru-sangat-muda);
        }

        tbody tr:hover {
            background-color: var(--biru-muda);
        }

        tbody tr:last-child {
            border-bottom: none;
        }

        td[colspan] {
            text-align: center;
            color: #64748b;
            padding: 24px;
        }

        .aksi {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .aksi form {
            margin: 0;
        }

        .aksi a,
        .btn-hapus {
            display: inline-block;
            padding: 6px 14px;
            border-radius: 6px;
            font-size: 0.85rem;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.15s ease;
        }

        .aksi a {
            background-color: var(--biru);
            color: #ffffff;
            border: 1px solid var(--biru);
        }

        .aksi a:hover {
            background-color: var(--biru-tua);
            border-color: var(--biru-tua);
        }

        .btn-hapus {
            background-color: #ffffff;
            color: var(--merah);
            border: 1px solid var(--merah);
        }

        .btn-hapus:hover {
            background-color: var(--merah);
            color: #ffffff;
        }

        @media (max-width: 768px) {
            body {
                padding: 12px;
            }

            table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }
        }
    </style>

    <h1>Data Staff Housekeeping</h1>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Petugas</th>
                <th>No. Kontak</th>
                <th>Area Penanganan</th>
                <th>Shift</th>
                <th>Tugas Kebersihan Harian</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $dataStaff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($staff->id); ?></td>
                    <td><?php echo e($staff->nama); ?></td>
                    <td><?php echo e($staff->kontak); ?></td>
                    <td><?php echo e($staff->area); ?></td>
                    <td><?php echo e($staff->shift); ?></td>
                    <td><?php echo e(implode(', ', $staff->tugas ?? [])); ?></td>
                    <td><?php echo e($staff->status); ?></td>
                    <td>
                        <div class="aksi">
                            <a href="<?php echo e(route('staff.edit', $staff)); ?>">Edit</a>

                            <form method="POST"
                                  action="<?php echo e(route('staff.destroy', $staff)); ?>"
                                  onsubmit="return confirm('Yakin ingin menghapus data ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-hapus">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8">Belum ada data staff.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projectlaravel\resources\views/staff/index.blade.php ENDPATH**/ ?>