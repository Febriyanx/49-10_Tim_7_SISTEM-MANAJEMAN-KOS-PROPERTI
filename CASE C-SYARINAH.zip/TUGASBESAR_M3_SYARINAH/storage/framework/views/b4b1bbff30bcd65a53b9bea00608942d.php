

<?php $__env->startSection('title', 'Tampilan Data'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Data Staff Housekeeping</h1>

    <div class="tabel-wrap">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Petugas</th>
                <th>No. Kontak</th>
                <th>Area Penanganan</th>
                <th>Shift</th>
                <th>Tugas Kebersihan Harian</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $dataStaff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($staff->id); ?></td>
                    <td><?php echo e($staff->nama); ?></td>
                    <td><?php echo e($staff->kontak); ?></td>
                    <td><?php echo e($staff->area); ?></td>
                    <td><span class="badge badge-biru"><?php echo e($staff->shift); ?></span></td>
                    <td><?php echo e(implode(', ', $staff->tugas ?? [])); ?></td>
                    <td><span class="badge <?php echo e(['Aktif' => 'badge-hijau', 'Cuti' => 'badge-kuning'][$staff->status] ?? 'badge-abu'); ?>"><?php echo e($staff->status); ?></span></td>
                    <td>
                        <div class="aksi">
                            <a href="<?php echo e(route('staff.edit', $staff)); ?>" class="btn-edit">Edit</a>

                            <form method="POST"
                                  action="<?php echo e(route('staff.destroy', $staff)); ?>"
                                  onsubmit="return confirm('Yakin ingin menghapus data ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-hapus">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8">Belum ada data staff.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\OneDrive\Documents\GitHub\WAD-RSAA-SYARINAH-102022500215\TUGASBESAR_M3_SYARINAH\resources\views/staff/index.blade.php ENDPATH**/ ?>