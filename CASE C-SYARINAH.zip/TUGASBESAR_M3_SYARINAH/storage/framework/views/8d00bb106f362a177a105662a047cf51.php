<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $__env->yieldContent('title'); ?> - Modul Housekeeper</title>

<style>
body {
    font-family: Arial, sans-serif;
    margin: 20px;
}

label {
    display: block;
    margin-top: 10px;
}

input[type="text"], select {
    width: 250px;
    padding: 5px;
    box-sizing: border-box;
}

nav a {
    margin-right: 15px;
}

button {
    padding: 8px 15px;
    cursor: pointer;
}

table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 20px;
}

th, td {
    border: 1px solid #7b7dde;
    padding: 8px;
    text-align: left;
}

th {
    background-color: #eeeeee;
}

.pesan {
    color: red;
    margin: 10px 0;
}

.sukses {
    color: green;
    margin: 10px 0;
}

.aksi {
    display: flex;
    gap: 10px;
    align-items: center;
}

.btn-hapus {
    border: none;
    background: none;
    color: red;
    text-decoration: underline;
    cursor: pointer;
    font: inherit;
    padding: 0;
}
</style>
</head>

<body>

<nav>
    <a href="<?php echo e(route('staff.create')); ?>">Form Input</a>
    <a href="<?php echo e(route('staff.index')); ?>">Tampilan Data</a>
</nav>

<?php if(session('success')): ?>
    <p class="sukses"><?php echo e(session('success')); ?></p>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="pesan">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php echo $__env->yieldContent('content'); ?>

</body>
</html><?php /**PATH D:\projectlaravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>