

<?php $__env->startSection('title', 'Edit Data'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Edit Data Staff Housekeeping</h1>

    <?php echo $__env->make('staff._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\OneDrive\Documents\GitHub\WAD-RSAA-SYARINAH-102022500215\TUGASBESAR_M3_SYARINAH\resources\views/staff/edit.blade.php ENDPATH**/ ?>