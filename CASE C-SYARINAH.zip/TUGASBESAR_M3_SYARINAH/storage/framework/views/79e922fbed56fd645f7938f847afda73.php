<?php
    $tugasTerpilih = old('tugas', $staff->tugas ?? []);
?>

<style>
    :root {
        --biru-tua: #1e3a8a;
        --biru: #2563eb;
        --biru-muda: #dbeafe;
        --biru-sangat-muda: #eff6ff;
        --teks: #1e293b;
        --border: #bfdbfe;
        --merah: #dc2626;
    }

    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background-color: var(--biru-sangat-muda);
        color: var(--teks);
        margin: 0;
        padding: 24px;
    }

    h1 {
        color: var(--biru-tua);
        font-size: 1.6rem;
        margin-bottom: 16px;
        padding-bottom: 8px;
        border-bottom: 3px solid var(--biru);
    }

    .form-staff {
        max-width: 560px;
        margin: 0 auto;
        padding: 28px;
        background-color: #ffffff;
        border-top: 6px solid var(--biru);
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.15);
    }

    .form-staff label {
        display: block;
        margin: 16px 0 6px;
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--biru-tua);
    }

    .form-staff input[type="text"],
    .form-staff select {
        width: 100%;
        box-sizing: border-box;
        padding: 10px 12px;
        font-size: 0.95rem;
        color: var(--teks);
        background-color: var(--biru-sangat-muda);
        border: 1px solid var(--border);
        border-radius: 6px;
        outline: none;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }

    .form-staff input[type="text"]:focus,
    .form-staff select:focus {
        border-color: var(--biru);
        background-color: #ffffff;
        box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.2);
    }

    .checkbox-group {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
        gap: 8px;
        padding: 12px;
        background-color: var(--biru-sangat-muda);
        border: 1px solid var(--border);
        border-radius: 6px;
    }

    .form-staff .checkbox-group label {
        display: flex;
        align-items: center;
        gap: 8px;
        margin: 0;
        font-weight: 400;
        color: var(--teks);
        cursor: pointer;
    }

    .form-staff input[type="checkbox"] {
        width: 16px;
        height: 16px;
        accent-color: var(--biru);
    }

    .form-aksi {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-top: 24px;
    }

    .btn-simpan,
    .btn-batal {
        display: inline-block;
        padding: 10px 20px;
        font-size: 0.9rem;
        font-weight: 500;
        border-radius: 6px;
        cursor: pointer;
        text-decoration: none;
        transition: all 0.15s ease;
    }

    .btn-simpan {
        background-color: var(--biru);
        color: #ffffff;
        border: 1px solid var(--biru);
    }

    .btn-simpan:hover {
        background-color: var(--biru-tua);
        border-color: var(--biru-tua);
    }

    .btn-batal {
        background-color: #ffffff;
        color: var(--biru);
        border: 1px solid var(--biru);
    }

    .btn-batal:hover {
        background-color: var(--biru-muda);
    }

    @media (max-width: 768px) {
        body {
            padding: 12px;
        }

        .form-staff {
            padding: 18px;
        }
    }
</style>

<form method="POST"
      class="form-staff"
      action="<?php echo e($staff->exists ? route('staff.update', $staff) : route('staff.store')); ?>">

    <?php echo csrf_field(); ?>
    <?php if($staff->exists): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <label for="nama">Nama Petugas</label>
    <input type="text" id="nama" name="nama"
           value="<?php echo e(old('nama', $staff->nama)); ?>" required>

    <label for="kontak">No. Kontak</label>
    <input type="text" id="kontak" name="kontak"
           value="<?php echo e(old('kontak', $staff->kontak)); ?>" required>

    <label for="area">Area Penanganan</label>
    <select id="area" name="area">
        <?php $__currentLoopData = \App\Models\Staff::AREA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($pilihan); ?>"
                <?php if(old('area', $staff->area ?? 'Lantai 1') === $pilihan): echo 'selected'; endif; ?>>
                <?php echo e($pilihan); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label for="shift">Shift</label>
    <select id="shift" name="shift">
        <?php $__currentLoopData = \App\Models\Staff::SHIFT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($pilihan); ?>"
                <?php if(old('shift', $staff->shift ?? 'Pagi') === $pilihan): echo 'selected'; endif; ?>>
                <?php echo e($pilihan); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label>Tugas Kebersihan Harian</label>
    <div class="checkbox-group">
        <?php $__currentLoopData = \App\Models\Staff::TUGAS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label>
                <input type="checkbox" name="tugas[]" value="<?php echo e($pilihan); ?>"
                    <?php if(in_array($pilihan, $tugasTerpilih, true)): echo 'checked'; endif; ?>>
                <?php echo e($pilihan); ?>

            </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <label for="status">Status</label>
    <select id="status" name="status">
        <?php $__currentLoopData = \App\Models\Staff::STATUS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($pilihan); ?>"
                <?php if(old('status', $staff->status ?? 'Aktif') === $pilihan): echo 'selected'; endif; ?>>
                <?php echo e($pilihan); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <div class="form-aksi">
        <button type="submit" class="btn-simpan"><?php echo e($staff->exists ? 'Update Data' : 'Simpan'); ?></button>

        <?php if($staff->exists): ?>
            <a href="<?php echo e(route('staff.index')); ?>" class="btn-batal">Batal Edit</a>
        <?php endif; ?>
    </div>

</form><?php /**PATH D:\projectlaravel\resources\views/staff/_form.blade.php ENDPATH**/ ?>