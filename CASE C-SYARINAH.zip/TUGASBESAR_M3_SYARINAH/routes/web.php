<?php

use App\Http\Controllers\StaffController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('staff.index');
});

Route::resource('staff', StaffController::class)->except('show');