@extends('layouts.app')

@section('title', 'Form Input')

@section('content')
    <h1>Form Input Data Staff Housekeeping</h1>

    @include('staff._form')
@endsection