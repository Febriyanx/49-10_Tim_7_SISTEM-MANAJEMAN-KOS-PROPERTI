@php
    $tugasTerpilih = old('tugas', $staff->tugas ?? []);
@endphp

<form method="POST"
      class="form-staff"
      action="{{ $staff->exists ? route('staff.update', $staff) : route('staff.store') }}">

    @csrf
    @if ($staff->exists)
        @method('PUT')
    @endif

    <label for="nama">Nama Petugas</label>
    <input type="text" id="nama" name="nama"
           value="{{ old('nama', $staff->nama) }}" required>

    <label for="kontak">No. Kontak</label>
    <input type="text" id="kontak" name="kontak"
           value="{{ old('kontak', $staff->kontak) }}" required>

    <label for="area">Area Penanganan</label>
    <select id="area" name="area">
        @foreach (\App\Models\Staff::AREA as $pilihan)
            <option value="{{ $pilihan }}"
                @selected(old('area', $staff->area ?? 'Lantai 1') === $pilihan)>
                {{ $pilihan }}
            </option>
        @endforeach
    </select>

    <label for="shift">Shift</label>
    <select id="shift" name="shift">
        @foreach (\App\Models\Staff::SHIFT as $pilihan)
            <option value="{{ $pilihan }}"
                @selected(old('shift', $staff->shift ?? 'Pagi') === $pilihan)>
                {{ $pilihan }}
            </option>
        @endforeach
    </select>

    <label>Tugas Kebersihan Harian</label>
    <div class="checkbox-group">
        @foreach (\App\Models\Staff::TUGAS as $pilihan)
            <label>
                <input type="checkbox" name="tugas[]" value="{{ $pilihan }}"
                    @checked(in_array($pilihan, $tugasTerpilih, true))>
                {{ $pilihan }}
            </label>
        @endforeach
    </div>

    <label for="status">Status</label>
    <select id="status" name="status">
        @foreach (\App\Models\Staff::STATUS as $pilihan)
            <option value="{{ $pilihan }}"
                @selected(old('status', $staff->status ?? 'Aktif') === $pilihan)>
                {{ $pilihan }}
            </option>
        @endforeach
    </select>

    <div class="form-aksi">
        <button type="submit" class="btn-simpan">{{ $staff->exists ? 'Update Data' : 'Simpan' }}</button>

        @if ($staff->exists)
            <a href="{{ route('staff.index') }}" class="btn-batal">Batal Edit</a>
        @endif
    </div>

</form>