@extends('layouts.app')

@section('title', 'Edit Data')

@section('content')
    <h1>Edit Data Staff Housekeeping</h1>

    @include('staff._form')
@endsection