@extends('layouts.app')

@section('title', 'Tampilan Data')

@section('content')

    <h1>Data Staff Housekeeping</h1>

    <div class="tabel-wrap">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Petugas</th>
                <th>No. Kontak</th>
                <th>Area Penanganan</th>
                <th>Shift</th>
                <th>Tugas Kebersihan Harian</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
            @forelse ($dataStaff as $staff)
                <tr>
                    <td>{{ $staff->id }}</td>
                    <td>{{ $staff->nama }}</td>
                    <td>{{ $staff->kontak }}</td>
                    <td>{{ $staff->area }}</td>
                    <td><span class="badge badge-biru">{{ $staff->shift }}</span></td>
                    <td>{{ implode(', ', $staff->tugas ?? []) }}</td>
                    <td><span class="badge {{ ['Aktif' => 'badge-hijau', 'Cuti' => 'badge-kuning'][$staff->status] ?? 'badge-abu' }}">{{ $staff->status }}</span></td>
                    <td>
                        <div class="aksi">
                            <a href="{{ route('staff.edit', $staff) }}" class="btn-edit">Edit</a>

                            <form method="POST"
                                  action="{{ route('staff.destroy', $staff) }}"
                                  onsubmit="return confirm('Yakin ingin menghapus data ini?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn-hapus">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="8">Belum ada data staff.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
    </div>
@endsection