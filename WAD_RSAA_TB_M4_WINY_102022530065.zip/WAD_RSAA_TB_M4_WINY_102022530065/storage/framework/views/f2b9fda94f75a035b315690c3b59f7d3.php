<?php $__env->startSection('title', 'Tambah Barang'); ?>
<?php $__env->startSection('subtitle', 'Modul Inventaris Aset Kos'); ?>
<?php $__env->startSection('card-class', 'form'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Form Tambah Barang</h2>

    <form action="<?php echo e(route('asets.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <?php echo $__env->make('asets._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <button type="submit" class="btn-simpan">Simpan</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\TUGASBESAR_M4_WINY\resources\views/asets/create.blade.php ENDPATH**/ ?>