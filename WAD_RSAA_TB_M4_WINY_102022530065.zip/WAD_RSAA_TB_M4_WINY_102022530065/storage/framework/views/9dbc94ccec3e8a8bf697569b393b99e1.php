<?php $__env->startSection('title', 'Akses Ditolak'); ?>

<?php $__env->startSection('content'); ?>
<div class="card" style="max-width: 520px; text-align:center;">
    <h1>403</h1>
    <h2>Akses ditolak</h2>
    <p><?php echo e($exception->getMessage() ?: 'Anda tidak memiliki izin untuk melakukan tindakan ini.'); ?></p>
    <p class="nav"><a href="<?php echo e(route('asets.index')); ?>">Kembali ke Daftar Aset</a></p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\TUGASBESAR_M3_WINY\resources\views\errors/403.blade.php ENDPATH**/ ?>