<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Inventaris Aset Kos'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
</head>
<body>
    <div class="card <?php echo $__env->yieldContent('card-class'); ?>">
        <div class="card-header">
            <div>
                <h1>🏠 Sistem Manajemen Kos</h1>
                <p><?php echo $__env->yieldContent('subtitle', 'Modul Inventaris Aset'); ?></p>
            </div>

            <?php if(auth()->guard()->check()): ?>
                <div class="nav-actions">
                    <span class="nav-user"><?php echo e(auth()->user()->name); ?> (<?php echo e(auth()->user()->role); ?>)</span>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola-aset')): ?>
                        <a href="<?php echo e(route('asets.create')); ?>"
                           class="nav-btn <?php echo e(request()->routeIs('asets.create') ? 'active' : ''); ?>">Form Input</a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('asets.index')); ?>"
                       class="nav-btn <?php echo e(request()->routeIs('asets.index') ? 'active' : ''); ?>">Tampilan Data</a>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" style="display:inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="nav-btn">Logout</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>

        <div class="card-body">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\TUGASBESAR_M3_WINY\resources\views/layouts/app.blade.php ENDPATH**/ ?>