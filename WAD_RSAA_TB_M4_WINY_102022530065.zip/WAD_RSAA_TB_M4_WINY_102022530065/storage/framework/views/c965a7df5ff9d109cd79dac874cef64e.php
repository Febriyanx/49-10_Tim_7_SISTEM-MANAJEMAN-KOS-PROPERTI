<?php $__env->startSection('title', 'Data Inventaris Kos'); ?>
<?php $__env->startSection('subtitle', 'Modul Inventaris Aset Kos'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert-sukses"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <h2>Data Inventaris Aset</h2>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>No</th><th>Nama Barang</th><th>Merek</th><th>Lokasi</th>
                    <th>Jumlah</th><th>Kondisi</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola-aset')): ?>
                        <th>Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $asets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($aset->nama_barang); ?></td>
                    <td><?php echo e($aset->merek); ?></td>
                    <td><?php echo e($aset->lokasi); ?></td>
                    <td><?php echo e($aset->jumlah); ?></td>
                    <td>
                        <span class="badge <?php echo e(match ($aset->kondisi) {
                            'Baik' => 'badge-baik',
                            'Rusak Ringan' => 'badge-ringan',
                            default => 'badge-berat',
                        }); ?>"><?php echo e($aset->kondisi); ?></span>
                    </td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola-aset')): ?>
                        <td>
                            <a class="btn-edit" href="<?php echo e(route('asets.edit', $aset)); ?>">Edit</a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('hapus-aset')): ?>
                                <form action="<?php echo e(route('asets.destroy', $aset)); ?>" method="POST" class="form-hapus"
                                      onsubmit="return confirm('Yakin hapus data ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn-hapus">Hapus</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="<?php echo e(auth()->user()->can('kelola-aset') ? 7 : 6); ?>" class="kosong">Belum ada data.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\TUGASBESAR_M4_WINY\resources\views/asets/index.blade.php ENDPATH**/ ?>