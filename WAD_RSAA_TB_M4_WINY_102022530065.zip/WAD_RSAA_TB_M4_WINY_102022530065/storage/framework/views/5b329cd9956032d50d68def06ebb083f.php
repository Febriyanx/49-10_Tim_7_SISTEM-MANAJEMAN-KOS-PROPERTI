<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Manajemen Kos</title>
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
</head>
<body>
<div class="login-page">
    <div class="card login-card">
        <div class="card-header">
            <h1>🏠 Sistem Manajemen Kos</h1>
            <p>Kontrol Akses Pengguna &amp; Inventaris Aset</p>
        </div>

        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert-sukses"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <form action="<?php echo e(route('login.proses')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="field">
                    <label for="email">Alamat Email</label>
                    <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" autofocus>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="field">
                    <label for="password">Kata Sandi</label>
                    <input type="password" id="password" name="password" placeholder="Masukkan kata sandi">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <label class="check">
                    <input type="checkbox" name="remember" value="1"> Ingat saya di perangkat ini
                </label>

                <button type="submit" class="btn-simpan">Masuk ke Sistem</button>
            </form>

            <div class="demo-box">
                <strong class="title">Akun demo (Role Access Control):</strong>
                Admin: <code>admin@example.com</code> | <code>password123</code><br>
                Staff: <code>staff@example.com</code> | <code>password123</code><br>
                Viewer: <code>viewer@example.com</code> | <code>password123</code>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\TUGASBESAR_M3_WINY\resources\views/auth/login.blade.php ENDPATH**/ ?>