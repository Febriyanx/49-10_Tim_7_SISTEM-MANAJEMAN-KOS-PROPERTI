<?php

use App\Http\Controllers\AsetController;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Route;

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])
        ->middleware('throttle:5,1')
        ->name('login.proses');
});

Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    Route::get('/', fn () => redirect()->route('asets.index'));


    Route::resource('asets', AsetController::class)->only(['index']);


    Route::middleware('role:admin,staff')->group(function () {
        Route::resource('asets', AsetController::class)
            ->only(['create', 'store', 'edit', 'update']);
    });


    Route::middleware('role:admin')->group(function () {
        Route::resource('asets', AsetController::class)->only(['destroy']);
    });
});
