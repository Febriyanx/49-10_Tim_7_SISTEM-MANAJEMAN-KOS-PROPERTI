<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('asets', function (Blueprint $table) {
            $table->id();
            $table->string('nama_barang');
            $table->string('merek')->nullable();
            $table->string('lokasi');
            $table->string('kondisi');
            $table->unsignedInteger('jumlah');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('asets');
    }
};
