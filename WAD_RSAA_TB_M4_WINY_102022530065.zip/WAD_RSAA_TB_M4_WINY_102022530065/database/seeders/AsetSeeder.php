<?php

namespace Database\Seeders;

use App\Models\Aset;
use Illuminate\Database\Seeder;

class AsetSeeder extends Seeder
{
    public function run(): void
    {
        $data = [
            ['AC Split 1 PK',            'Daikin',   'Kamar 1',      'Baik',         12],
            ['Kasur Spring Bed 120x200', 'Comforta', 'Kamar 2',      'Baik',         20],
            ['Lemari Pakaian 2 Pintu',   'Olympic',  'Kamar 3',      'Rusak Ringan',  8],
            ['TV LED 32 inch',           'Samsung',  'Ruang Santai', 'Baik',          2],
            ['Kursi Belajar',            'IKEA',     'Kamar 4',      'Rusak Berat',   3],
        ];

        foreach ($data as [$nama, $merek, $lokasi, $kondisi, $jumlah]) {

            Aset::firstOrCreate(
                ['nama_barang' => $nama, 'lokasi' => $lokasi],
                ['merek' => $merek, 'kondisi' => $kondisi, 'jumlah' => $jumlah],
            );
        }
    }
}
