<?php

namespace Tests\Feature;

use App\Models\Aset;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AksesAsetTest extends TestCase
{
    use RefreshDatabase;

    private function user(string $role): User
    {
        return User::factory()->create(['role' => $role]);
    }

    private function aset(): Aset
    {
        return Aset::create([
            'nama_barang' => 'Kipas Angin', 'merek' => 'Maspion', 'lokasi' => 'Kamar 1',
            'jumlah' => 2, 'kondisi' => 'Baik',
        ]);
    }

    private function payload(array $o = []): array
    {
        return array_merge([
            'nama_barang' => 'Rice Cooker', 'merek' => 'Miyako', 'lokasi' => 'Dapur',
            'jumlah' => 1, 'kondisi' => 'Baik',
        ], $o);
    }

    public function test_tamu_diarahkan_ke_login(): void
    {
        $this->get('/asets')->assertRedirect('/login');
        $this->get('/asets/create')->assertRedirect('/login');
        $this->post('/asets', $this->payload())->assertRedirect('/login');
    }

    public function test_viewer_hanya_boleh_lihat(): void
    {
        $a = $this->aset();
        $v = $this->user('viewer');

        $this->actingAs($v)->get('/asets')->assertOk()->assertSee('Kipas Angin')
            ->assertDontSee('Tambah Barang')->assertDontSee('Hapus');
        $this->actingAs($v)->get('/asets/create')->assertForbidden();
        $this->actingAs($v)->post('/asets', $this->payload())->assertForbidden();
        $this->actingAs($v)->get("/asets/{$a->id}/edit")->assertForbidden();
        $this->actingAs($v)->put("/asets/{$a->id}", $this->payload())->assertForbidden();
        $this->actingAs($v)->delete("/asets/{$a->id}")->assertForbidden();
        $this->assertDatabaseCount('asets', 1);
    }

    public function test_staff_boleh_tambah_edit_tapi_tidak_hapus(): void
    {
        $a = $this->aset();
        $s = $this->user('staff');

        $this->actingAs($s)->get('/asets')->assertOk()->assertSee('Tambah Barang')->assertSee('Edit')->assertDontSee('Hapus');
        $this->actingAs($s)->post('/asets', $this->payload())->assertRedirect('/asets');
        $this->actingAs($s)->get("/asets/{$a->id}/edit")->assertOk();
        $this->actingAs($s)->put("/asets/{$a->id}", $this->payload(['nama_barang' => 'Kipas Baru']))->assertRedirect('/asets');
        $this->assertDatabaseHas('asets', ['id' => $a->id, 'nama_barang' => 'Kipas Baru']);

        $this->actingAs($s)->delete("/asets/{$a->id}")->assertForbidden();
        $this->assertDatabaseHas('asets', ['id' => $a->id]);
    }

    public function test_admin_boleh_semua(): void
    {
        $a = $this->aset();
        $admin = $this->user('admin');

        $this->actingAs($admin)->get('/asets')->assertOk()->assertSee('Hapus');
        $this->actingAs($admin)->post('/asets', $this->payload())->assertRedirect('/asets');
        $this->actingAs($admin)->delete("/asets/{$a->id}")->assertRedirect('/asets');
        $this->assertDatabaseMissing('asets', ['id' => $a->id]);
    }

    public function test_validasi_kondisi_harus_valid(): void
    {
        $this->actingAs($this->user('admin'))
            ->post('/asets', $this->payload(['kondisi' => 'Ngawur']))
            ->assertSessionHasErrors('kondisi');
    }
}
