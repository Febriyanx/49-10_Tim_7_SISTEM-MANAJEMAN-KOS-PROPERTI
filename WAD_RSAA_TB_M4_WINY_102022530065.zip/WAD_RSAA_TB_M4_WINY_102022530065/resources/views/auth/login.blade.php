<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Manajemen Kos</title>
    <link rel="stylesheet" href="{{ asset('style.css') }}">
</head>
<body>
<div class="login-page">
    <div class="card login-card">
        <div class="card-header">
            <h1>🏠 Sistem Manajemen Kos</h1>
            <p>Kontrol Akses Pengguna &amp; Inventaris Aset</p>
        </div>

        <div class="card-body">
            @if (session('success'))
                <div class="alert-sukses">{{ session('success') }}</div>
            @endif

            <form action="{{ route('login.proses') }}" method="POST">
                @csrf

                <div class="field">
                    <label for="email">Alamat Email</label>
                    <input type="email" id="email" name="email" value="{{ old('email') }}" autofocus>
                    @error('email') <span class="error">{{ $message }}</span> @enderror
                </div>

                <div class="field">
                    <label for="password">Kata Sandi</label>
                    <input type="password" id="password" name="password" placeholder="Masukkan kata sandi">
                    @error('password') <span class="error">{{ $message }}</span> @enderror
                </div>

                <label class="check">
                    <input type="checkbox" name="remember" value="1"> Ingat saya di perangkat ini
                </label>

                <button type="submit" class="btn-simpan">Masuk ke Sistem</button>
            </form>

            <div class="demo-box">
                <strong class="title">Akun demo (Role Access Control):</strong>
                Admin: <code>admin@example.com</code> | <code>password123</code><br>
                Staff: <code>staff@example.com</code> | <code>password123</code><br>
                Viewer: <code>viewer@example.com</code> | <code>password123</code>
            </div>
        </div>
    </div>
</div>
</body>
</html>
