@extends('layouts.app')

@section('title', 'Akses Ditolak')
@section('subtitle', 'Akses Ditolak')
@section('card-class', 'form')

@section('content')
    <div style="text-align:center">
        <h2>403 - Akses ditolak</h2>
        <p>{{ $exception->getMessage() ?: 'Anda tidak memiliki izin untuk melakukan tindakan ini.' }}</p>
        <p><a class="btn-edit" href="{{ route('asets.index') }}">Kembali ke Daftar Aset</a></p>
    </div>
@endsection
