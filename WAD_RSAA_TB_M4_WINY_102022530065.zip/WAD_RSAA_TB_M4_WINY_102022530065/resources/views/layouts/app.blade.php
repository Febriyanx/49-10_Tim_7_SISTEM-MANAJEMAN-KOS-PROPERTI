<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Inventaris Aset Kos')</title>
    <link rel="stylesheet" href="{{ asset('style.css') }}">
</head>
<body>
    <div class="card @yield('card-class')">
        <div class="card-header">
            <div>
                <h1>🏠 Sistem Manajemen Kos</h1>
                <p>@yield('subtitle', 'Modul Inventaris Aset')</p>
            </div>

            @auth
                <div class="nav-actions">
                    <span class="nav-user">{{ auth()->user()->name }} ({{ auth()->user()->role }})</span>
                    @can('kelola-aset')
                        <a href="{{ route('asets.create') }}"
                           class="nav-btn {{ request()->routeIs('asets.create') ? 'active' : '' }}">Form Input</a>
                    @endcan
                    <a href="{{ route('asets.index') }}"
                       class="nav-btn {{ request()->routeIs('asets.index') ? 'active' : '' }}">Tampilan Data</a>
                    <form action="{{ route('logout') }}" method="POST" style="display:inline">
                        @csrf
                        <button type="submit" class="nav-btn">Logout</button>
                    </form>
                </div>
            @endauth
        </div>

        <div class="card-body">
            @yield('content')
        </div>
    </div>
</body>
</html>
