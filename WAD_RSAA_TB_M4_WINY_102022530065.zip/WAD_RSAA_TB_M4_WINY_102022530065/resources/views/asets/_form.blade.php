
@php $aset = $aset ?? null; @endphp

  <div class="field">
      <label for="nama_barang">Nama Barang</label>
      <input type="text" id="nama_barang" name="nama_barang" value="{{ old('nama_barang', $aset?->nama_barang) }}">
      @error('nama_barang') <span class="error">{{ $message }}</span> @enderror
  </div>

<div class="field">
    <label for="merek">Merek</label>
    <input type="text" id="merek" name="merek" value="{{ old('merek', $aset?->merek) }}">
    @error('merek') <span class="error">{{ $message }}</span> @enderror
</div>

<div class="field">
    <label for="lokasi">Lokasi / Kamar</label>
    <input type="text" id="lokasi" name="lokasi" value="{{ old('lokasi', $aset?->lokasi) }}">
    @error('lokasi') <span class="error">{{ $message }}</span> @enderror
</div>

<div class="field">
    <label for="jumlah">Jumlah</label>
    <input type="number" id="jumlah" name="jumlah" min="1" value="{{ old('jumlah', $aset?->jumlah) }}">
    @error('jumlah') <span class="error">{{ $message }}</span> @enderror
</div>

<div class="field">
    <label for="kondisi">Kondisi fisik</label>
    <select id="kondisi" name="kondisi">
        <option value="">Pilih...</option>
        @foreach (\App\Models\Aset::KONDISI as $k)
            <option value="{{ $k }}" @selected(old('kondisi', $aset?->kondisi) === $k)>{{ $k }}</option>
        @endforeach
    </select>
    @error('kondisi') <span class="error">{{ $message }}</span> @enderror
</div>
