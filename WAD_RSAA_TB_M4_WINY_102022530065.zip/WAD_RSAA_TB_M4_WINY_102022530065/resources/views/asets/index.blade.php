@extends('layouts.app')

@section('title', 'Data Inventaris Kos')
@section('subtitle', 'Modul Inventaris Aset Kos')

@section('content')
    @if (session('success'))
        <div class="alert-sukses">{{ session('success') }}</div>
    @endif

    <h2>Data Inventaris Aset</h2>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>No</th><th>Nama Barang</th><th>Merek</th><th>Lokasi</th>
                    <th>Jumlah</th><th>Kondisi</th>
                    @can('kelola-aset')
                        <th>Aksi</th>
                    @endcan
                </tr>
            </thead>
            <tbody>
                @forelse ($asets as $aset)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $aset->nama_barang }}</td>
                    <td>{{ $aset->merek }}</td>
                    <td>{{ $aset->lokasi }}</td>
                    <td>{{ $aset->jumlah }}</td>
                    <td>
                        <span class="badge {{ match ($aset->kondisi) {
                            'Baik' => 'badge-baik',
                            'Rusak Ringan' => 'badge-ringan',
                            default => 'badge-berat',
                        } }}">{{ $aset->kondisi }}</span>
                    </td>
                    @can('kelola-aset')
                        <td>
                            <a class="btn-edit" href="{{ route('asets.edit', $aset) }}">Edit</a>
                            @can('hapus-aset')
                                <form action="{{ route('asets.destroy', $aset) }}" method="POST" class="form-hapus"
                                      onsubmit="return confirm('Yakin hapus data ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-hapus">Hapus</button>
                                </form>
                            @endcan
                        </td>
                    @endcan
                </tr>
                @empty
                <tr>
                    <td colspan="{{ auth()->user()->can('kelola-aset') ? 7 : 6 }}" class="kosong">Belum ada data.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
@endsection
