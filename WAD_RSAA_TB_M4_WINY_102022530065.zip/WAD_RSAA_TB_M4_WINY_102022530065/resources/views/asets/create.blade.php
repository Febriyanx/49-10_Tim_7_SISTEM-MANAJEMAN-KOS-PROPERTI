@extends('layouts.app')

@section('title', 'Tambah Barang')
@section('subtitle', 'Modul Inventaris Aset Kos')
@section('card-class', 'form')

@section('content')
    <h2>Form Tambah Barang</h2>

    <form action="{{ route('asets.store') }}" method="POST">
        @csrf

        @include('asets._form')

        <button type="submit" class="btn-simpan">Simpan</button>
    </form>
@endsection
