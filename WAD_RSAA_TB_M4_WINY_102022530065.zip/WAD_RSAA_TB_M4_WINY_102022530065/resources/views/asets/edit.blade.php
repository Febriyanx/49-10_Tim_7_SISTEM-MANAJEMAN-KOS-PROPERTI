@extends('layouts.app')

@section('title', 'Edit Barang')
@section('subtitle', 'Modul Inventaris Aset Kos')
@section('card-class', 'form')

@section('content')
    <h2>Edit Barang</h2>

    <form action="{{ route('asets.update', $aset) }}" method="POST">
        @csrf
        @method('PUT')

        @include('asets._form')

        <button type="submit" class="btn-simpan">Simpan Perubahan</button>
    </form>
@endsection
