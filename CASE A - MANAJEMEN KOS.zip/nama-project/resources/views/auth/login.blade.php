<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Management Kost</title>

    <style>
        :root {
            --navy: #1e293b;
            --navy-dark: #0f172a;
            --primary: #c2410c;
            --primary-dark: #9a3412;
            --primary-soft: #ffedd5;
            --accent: #f59e0b;
            --text: #1f2937;
            --muted: #64748b;
            --border: #cbd5e1;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
            background: #f8fafc;
            color: var(--text);
        }

        .wrapper {
            width: 100%;
            max-width: 880px;
            min-height: 500px;
            display: flex;
            background: #ffffff;
            border-radius: 20px;
            box-shadow: 0 15px 40px rgba(15, 23, 42, 0.15);
            overflow: hidden;
        }

        /* ===== PANEL KIRI ===== */
        .side {
            flex: 1;
            position: relative;
            padding: 44px 36px;
            color: #ffffff;
            background: linear-gradient(155deg, var(--navy) 0%, var(--navy-dark) 100%);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            overflow: hidden;
        }

        .side::before,
        .side::after {
            content: "";
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.07);
        }

        .side::before {
            width: 240px;
            height: 240px;
            top: -80px;
            right: -80px;
        }

        .side::after {
            width: 180px;
            height: 180px;
            bottom: -60px;
            left: -50px;
        }

        .brand {
            position: relative;
            z-index: 1;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 18px;
            font-weight: 700;
        }

        .brand-icon {
            width: 38px;
            height: 38px;
            border-radius: 10px;
            background: var(--accent);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .side-text {
            position: relative;
            z-index: 1;
        }

        .side-text h2 {
            margin: 0 0 10px;
            font-size: 28px;
            line-height: 1.25;
        }

        .side-text p {
            margin: 0;
            font-size: 14px;
            line-height: 1.6;
            color: #cbd5e1;
        }

        .side-foot {
            position: relative;
            z-index: 1;
            font-size: 12px;
            color: #94a3b8;
        }

        /* ===== PANEL KANAN (FORM) ===== */
        .form-side {
            flex: 1;
            padding: 48px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .form-side h1 {
            margin: 0 0 6px;
            font-size: 26px;
            color: var(--navy);
        }

        .form-side .desc {
            margin: 0 0 26px;
            font-size: 14px;
            color: var(--muted);
        }

        .error {
            background: #fef2f2;
            color: #b91c1c;
            border-left: 4px solid #ef4444;
            padding: 10px 13px;
            border-radius: 6px;
            font-size: 13px;
            margin-bottom: 18px;
        }

        .field {
            margin-bottom: 18px;
        }

        .field label {
            display: block;
            margin-bottom: 7px;
            font-size: 13px;
            font-weight: 600;
        }

        .input-wrap {
            position: relative;
        }

        .input-wrap input {
            width: 100%;
            padding: 12px 14px;
            border: 1.5px solid var(--border);
            border-radius: 10px;
            font-size: 14px;
            font-family: inherit;
            color: var(--text);
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        .input-wrap input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px var(--primary-soft);
        }

        .input-wrap.has-toggle input {
            padding-right: 70px;
        }

        .toggle {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--primary);
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
        }

        .remember {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 22px;
            font-size: 13px;
            color: var(--muted);
        }

        .remember input {
            accent-color: var(--primary);
            width: 15px;
            height: 15px;
            margin: 0;
        }

        .btn {
            width: 100%;
            padding: 13px;
            border: none;
            border-radius: 10px;
            background: var(--primary);
            color: #ffffff;
            font-size: 14px;
            font-weight: 700;
            font-family: inherit;
            cursor: pointer;
            transition: background 0.2s, transform 0.1s;
        }

        .btn:hover {
            background: var(--primary-dark);
        }

        .btn:active {
            transform: scale(0.99);
        }

        @media (max-width: 720px) {
            .wrapper {
                flex-direction: column;
                min-height: auto;
            }

            .side {
                padding: 28px 24px;
                gap: 20px;
            }

            .side-text h2 {
                font-size: 22px;
            }

            .side-foot {
                display: none;
            }

            .form-side {
                padding: 32px 24px;
            }
        }
    </style>
</head>

<body>
    <div class="wrapper">

        <div class="side">
            <div class="brand">
                <div class="brand-icon">🔑</div>
                Management Kost
            </div>

            <div class="side-text">
                <h2>Kelola kost lebih rapi dan mudah.</h2>
                <p>Pantau data kamar, penghuni, dan status hunian dalam satu tempat.</p>
            </div>

            <div class="side-foot">&copy; {{ date('Y') }} Management Kost</div>
        </div>

        <div class="form-side">
            <h1>Selamat Datang</h1>
            <p class="desc">Silakan masuk untuk mengelola data kost.</p>

            @if ($errors->any())
                <div class="error">
                    {{ $errors->first() }}
                </div>
            @endif

            <form action="{{ route('login') }}" method="POST">
                @csrf

                <div class="field">
                    <label for="email">Email</label>
                    <div class="input-wrap">
                        <input type="email"
                               id="email"
                               name="email"
                               value="{{ old('email') }}"
                               placeholder="nama@email.com"
                               required
                               autofocus>
                    </div>
                </div>

                <div class="field">
                    <label for="password">Password</label>
                    <div class="input-wrap has-toggle">
                        <input type="password"
                               id="password"
                               name="password"
                               placeholder="Masukkan password"
                               required>
                        <button type="button" class="toggle" onclick="togglePassword(this)">Lihat</button>
                    </div>
                </div>

                <div class="remember">
                    <input type="checkbox" id="remember" name="remember">
                    <label for="remember">Ingat saya</label>
                </div>

                <button type="submit" class="btn">Masuk</button>
            </form>
        </div>

    </div>

    <script>
        function togglePassword(btn) {
            const input = document.getElementById('password');
            const show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            btn.textContent = show ? 'Sembunyi' : 'Lihat';
        }
    </script>
</body>
</html>