
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\KamarController;

Route::get('/', function () {
    return redirect()->route('kamars.index');
});

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])
        ->name('login');

    Route::post('/login', [AuthController::class, 'login'])
        ->name('login.process');
});

Route::middleware('auth')->group(function () {

    Route::post('/logout', [AuthController::class, 'logout'])
        ->name('logout');

    // Admin dan User hanya bisa melihat daftar kamar
    Route::middleware('role:admin,user')->group(function () {
        Route::get('/kamars', [KamarController::class, 'index'])
            ->name('kamars.index');
    });

    // Khusus Admin: tambah, edit, dan hapus
    Route::middleware('role:admin')->group(function () {
        Route::resource('kamars', KamarController::class)
            ->except(['index', 'show']);
    });

});
