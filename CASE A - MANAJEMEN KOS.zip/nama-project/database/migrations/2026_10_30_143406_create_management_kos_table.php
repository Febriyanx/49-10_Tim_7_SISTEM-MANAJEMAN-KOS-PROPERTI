<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('management_kos', function (Blueprint $table) {
            $table->id();
            $table->string('tipe_kamar', 50);
            $table->string('ukuran_ruangan', 20);
            $table->decimal('harga_sewa', 10, 2);
            $table->text('fasilitas')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('management_kos');
    }
};