<?php

namespace App\Http\Controllers;

use App\Models\Kamar;
use Illuminate\Http\Request;

class KamarController extends Controller
{
    
    public function index()
    {
        $kamars = Kamar::latest()->get();

        return view('kamars.index', compact('kamars'));
    }

    
    public function create()
    {
        return view('kamars.create');
    }

    
    public function store(Request $request)
    {
        $request->validate([
            'nomor_kamar' => 'required|unique:kamars,nomor_kamar',
            'tipe_kamar' => 'required',
            'tipe_kamar' => 'required',
            'harga' => 'required|numeric',
            'fasilitas' => 'nullable',
            'status' => 'required',
            'keterangan' => 'nullable',
        ]);

        Kamar::create($request->except('_token'));

        return redirect()->route('kamars.index')
            ->with('success', 'Data kamar berhasil ditambahkan!');
    }

    
    public function edit(Kamar $kamar)
    {
        return view('kamars.edit', compact('kamar'));
    }

    
    public function update(Request $request, Kamar $kamar)
    {
        $request->validate([
            'nomor_kamar' => 'required|unique:kamars,nomor_kamar,' . $kamar->id,
             'nama_penghuni' => 'nullable|string|max:255',
            'tipe_kamar' => 'required',
            'harga' => 'required|numeric',
            'fasilitas' => 'nullable',
            'status' => 'required',
            'keterangan' => 'nullable',
        ]);

        $kamar->update($request->except(['_token', '_method']));

        return redirect()->route('kamars.index')
            ->with('success', 'Data kamar berhasil diperbarui!');
    }


    public function destroy(Kamar $kamar)
    {
        $kamar->delete();

        return redirect()->route('kamars.index')
            ->with('success', 'Data kamar berhasil dihapus!');
    }
}