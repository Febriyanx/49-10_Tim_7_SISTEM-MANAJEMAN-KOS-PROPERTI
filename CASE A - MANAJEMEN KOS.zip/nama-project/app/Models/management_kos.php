<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class management_kos extends Model
{
    //
}
