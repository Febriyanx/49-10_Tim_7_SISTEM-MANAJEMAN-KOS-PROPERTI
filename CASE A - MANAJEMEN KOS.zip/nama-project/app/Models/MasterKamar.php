<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MasterKamar extends Model
{
    protected $table = 'master_kamar';

    public $timestamps = false;

    protected $fillable = [
        'tipe_kamar',
        'ukuran_ruangan',
        'harga_sewa',
        'fasilitas'
    ];
}