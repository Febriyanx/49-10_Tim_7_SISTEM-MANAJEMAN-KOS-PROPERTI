<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kamar</title>

    <style>
        :root {
            --navy: #1e293b;
            --navy-dark: #0f172a;
            --primary: #c2410c;
            --primary-dark: #9a3412;
            --primary-soft: #ffedd5;
            --accent: #f59e0b;
            --text: #1f2937;
            --muted: #64748b;
            --border: #cbd5e1;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            padding: 32px 20px;
            font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
            background: #f8fafc;
            color: var(--text);
        }

        .container {
            max-width: 660px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 18px;
            box-shadow: 0 10px 30px rgba(15, 23, 42, 0.12);
            overflow: hidden;
        }

        /* ===== HEADER FORM ===== */
        .form-header {
            position: relative;
            padding: 28px 32px;
            color: #ffffff;
            background: linear-gradient(155deg, var(--navy) 0%, var(--navy-dark) 100%);
            overflow: hidden;
        }

        .form-header::after {
            content: "";
            position: absolute;
            width: 180px;
            height: 180px;
            top: -70px;
            right: -50px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
        }

        .form-header .tag {
            position: relative;
            z-index: 1;
            display: inline-block;
            background: var(--accent);
            color: #78350f;
            font-size: 11px;
            font-weight: 700;
            padding: 3px 10px;
            border-radius: 999px;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-header h1 {
            position: relative;
            z-index: 1;
            margin: 0 0 6px;
            font-size: 24px;
        }

        .form-header .subtitle {
            position: relative;
            z-index: 1;
            margin: 0;
            font-size: 14px;
            color: #cbd5e1;
        }

        .form-body {
            padding: 30px 32px 34px;
        }

        /* ===== FORM ===== */
        .form-group {
            margin-bottom: 18px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-size: 13px;
            font-weight: 600;
            color: var(--text);
        }

        input, select, textarea {
            width: 100%;
            padding: 12px 14px;
            border: 1.5px solid var(--border);
            border-radius: 10px;
            font-size: 14px;
            font-family: inherit;
            color: var(--text);
            background: #ffffff;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        input::placeholder, textarea::placeholder {
            color: #9ca3af;
        }

        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px var(--primary-soft);
        }

        textarea {
            resize: vertical;
            min-height: 85px;
        }

        .error {
            color: #dc2626;
            font-size: 12px;
            margin-top: 6px;
        }

        .actions {
            display: flex;
            gap: 10px;
            margin-top: 28px;
        }

        button, .back-button {
            border: none;
            border-radius: 10px;
            padding: 13px 22px;
            font-size: 14px;
            font-family: inherit;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
            transition: background 0.2s;
        }

        button {
            background: var(--primary);
            color: #ffffff;
            flex: 1;
        }

        button:hover {
            background: var(--primary-dark);
        }

        .back-button {
            background: var(--primary-soft);
            color: var(--primary-dark);
        }

        .back-button:hover {
            background: #fed7aa;
        }

        @media (max-width: 480px) {
            body {
                padding: 16px 12px;
            }

            .form-header,
            .form-body {
                padding-left: 22px;
                padding-right: 22px;
            }

            .actions {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>
    <div class="container">

        <div class="form-header">
            <span class="tag">Ubah Data</span>
            <h1>Edit Kamar</h1>
            <p class="subtitle">Perbarui informasi kamar kost yang dipilih.</p>
        </div>

        <div class="form-body">
            <form action="<?php echo e(route('kamars.update', $kamar->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label for="nomor_kamar">Nomor Kamar</label>
                    <input type="text" id="nomor_kamar" name="nomor_kamar"
                        value="<?php echo e(old('nomor_kamar', $kamar->nomor_kamar)); ?>"
                        placeholder="Contoh: A01" required>
                    <?php $__errorArgs = ['nomor_kamar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="nama_penghuni">Nama Penghuni</label>
                    <input type="text" id="nama_penghuni" name="nama_penghuni"
                        value="<?php echo e(old('nama_penghuni', $kamar->nama_penghuni)); ?>"
                        placeholder="Masukkan nama penghuni">
                    <?php $__errorArgs = ['nama_penghuni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="tipe_kamar">Tipe Kamar</label>
                    <select id="tipe_kamar" name="tipe_kamar" required>
                        <option value="">Pilih Tipe Kamar</option>
                        <option value="Standard" <?php echo e(old('tipe_kamar', $kamar->tipe_kamar) == 'Standard' ? 'selected' : ''); ?>>Standard</option>
                        <option value="Deluxe" <?php echo e(old('tipe_kamar', $kamar->tipe_kamar) == 'Deluxe' ? 'selected' : ''); ?>>Deluxe</option>
                        <option value="Premium" <?php echo e(old('tipe_kamar', $kamar->tipe_kamar) == 'Premium' ? 'selected' : ''); ?>>Premium</option>
                        <option value="VIP" <?php echo e(old('tipe_kamar', $kamar->tipe_kamar) == 'VIP' ? 'selected' : ''); ?>>VIP</option>
                    </select>
                    <?php $__errorArgs = ['tipe_kamar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="harga">Harga Kamar</label>
                    <input type="number" id="harga" name="harga"
                        value="<?php echo e(old('harga', $kamar->harga)); ?>"
                        placeholder="Contoh: 1000000" required>
                    <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="fasilitas">Fasilitas</label>
                    <textarea id="fasilitas" name="fasilitas"
                        placeholder="Contoh: WiFi, AC, kamar mandi dalam"><?php echo e(old('fasilitas', $kamar->fasilitas)); ?></textarea>
                    <?php $__errorArgs = ['fasilitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="status">Status Kamar</label>
                    <select id="status" name="status" required>
                        <option value="">Pilih status kamar</option>
                        <option value="Tersedia" <?php echo e(old('status', $kamar->status) == 'Tersedia' ? 'selected' : ''); ?>>Tersedia</option>
                        <option value="Terisi" <?php echo e(old('status', $kamar->status) == 'Terisi' ? 'selected' : ''); ?>>Terisi</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="keterangan">Keterangan</label>
                    <textarea id="keterangan" name="keterangan"
                        placeholder="Tambahkan keterangan jika diperlukan"><?php echo e(old('keterangan', $kamar->keterangan)); ?></textarea>
                    <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="actions">
                    <button type="submit">Simpan Perubahan</button>
                    <a href="<?php echo e(route('kamars.index')); ?>" class="back-button">Kembali</a>
                </div>
            </form>
        </div>

    </div>
</body>
</html><?php /**PATH C:\Users\TIARA\nama-project\resources\views/kamars/edit.blade.php ENDPATH**/ ?>