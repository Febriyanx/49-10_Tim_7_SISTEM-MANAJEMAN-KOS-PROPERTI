
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Management Kost</title>

    <style>
        :root {
            --navy: #1e293b;
            --navy-dark: #0f172a;
            --primary: #c2410c;
            --primary-dark: #9a3412;
            --primary-soft: #ffedd5;
            --accent: #f59e0b;
            --text: #1f2937;
            --muted: #64748b;
            --border: #cbd5e1;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
            background: #f8fafc;
            color: var(--text);
        }

        /* TOPBAR */
        .topbar {
            background: #ffffff;
            border-bottom: 1px solid var(--border);
            box-shadow: 0 2px 10px rgba(15, 23, 42, 0.06);
        }

        .topbar-inner {
            max-width: 1150px;
            margin: 0 auto;
            padding: 14px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 18px;
            font-weight: 700;
            color: var(--navy);
        }

        .brand-icon {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            background: var(--accent);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }

        .logout-button {
            background: transparent;
            color: var(--primary);
            border: 1.5px solid var(--primary);
            padding: 8px 16px;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 700;
            font-family: inherit;
            cursor: pointer;
            transition: all 0.2s;
        }

        .logout-button:hover {
            background: var(--primary);
            color: #ffffff;
        }

        /* MAIN */
        .main {
            max-width: 1150px;
            margin: 0 auto;
            padding: 28px 24px 40px;
        }

        .page-head {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            flex-wrap: wrap;
            gap: 14px;
            margin-bottom: 22px;
        }

        .page-head h1 {
            margin: 0 0 4px;
            font-size: 26px;
            color: var(--navy);
        }

        .page-head p {
            margin: 0;
            font-size: 14px;
            color: var(--muted);
        }

        .add-button {
            display: inline-block;
            background: var(--primary);
            color: #ffffff;
            padding: 11px 18px;
            border-radius: 10px;
            text-decoration: none;
            font-size: 14px;
            font-weight: 700;
            transition: background 0.2s;
        }

        .add-button:hover {
            background: var(--primary-dark);
        }

        .success {
            background: #ecfdf5;
            color: #065f46;
            border-left: 4px solid #10b981;
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        /* STAT CARDS */
        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
            margin-bottom: 22px;
        }

        .stat {
            background: #ffffff;
            border-radius: 14px;
            padding: 18px 20px;
            box-shadow: 0 4px 14px rgba(15, 23, 42, 0.08);
            border-top: 4px solid var(--primary);
        }

        .stat.amber {
            border-top-color: var(--accent);
        }

        .stat.green {
            border-top-color: #10b981;
        }

        .stat .label {
            font-size: 12px;
            font-weight: 600;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat .value {
            margin-top: 6px;
            font-size: 28px;
            font-weight: 700;
            color: var(--text);
        }

        /* TABLE CARD */
        .card {
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 6px 20px rgba(15, 23, 42, 0.1);
            overflow: hidden;
        }

        .table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 900px;
        }

        th {
            background: #f1f5f9;
            color: var(--navy);
            padding: 14px 16px;
            text-align: left;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        td {
            padding: 15px 16px;
            border-bottom: 1px solid #f3f4f6;
            font-size: 14px;
            color: #374151;
        }

        tbody tr:last-child td {
            border-bottom: none;
        }

        tbody tr:hover td {
            background: #f8fafc;
        }

        .room-number {
            font-weight: 700;
            color: var(--navy);
        }

        /* BADGE */
        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 700;
        }

        .badge-success {
            background: #d1fae5;
            color: #065f46;
        }

        .badge-warning {
            background: #fef3c7;
            color: #92400e;
        }

        /* AKSI */
        .aksi {
            display: flex;
            gap: 6px;
            align-items: center;
        }

        .edit-button {
            display: inline-block;
            background: var(--primary-soft);
            color: var(--primary-dark);
            padding: 7px 13px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 600;
        }

        .edit-button:hover {
            background: #fed7aa;
        }

        .delete-button {
            background: #fee2e2;
            color: #b91c1c;
            border: none;
            padding: 7px 13px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            font-family: inherit;
            cursor: pointer;
        }

        .delete-button:hover {
            background: #fecaca;
        }

        .empty {
            text-align: center;
            padding: 36px;
            color: var(--muted);
        }

        @media (max-width: 700px) {
            .stats {
                grid-template-columns: 1fr;
            }

            .topbar-inner,
            .main {
                padding-left: 16px;
                padding-right: 16px;
            }
        }
    </style>
</head>

<body>

    <div class="topbar">
        <div class="topbar-inner">
            <div class="brand">
                <div class="brand-icon">🔑</div>
                Management Kost
            </div>

            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="logout-button">Logout</button>
            </form>
        </div>
    </div>

    <div class="main">

        <div class="page-head">
            <div>
                <h1>Data Kamar Kost</h1>
                <p>Kelola kamar, penghuni, dan status hunian.</p>
            </div>

            
            <?php if(auth()->user()->role === 'admin'): ?>
                <a href="<?php echo e(route('kamars.create')); ?>" class="add-button">
                    + Tambah Kamar
                </a>
            <?php endif; ?>
        </div>

        <?php if(session('success')): ?>
            <div class="success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php
            $total = $kamars->count();

            $tersediaCount = $kamars->filter(function ($k) {
                return in_array(strtolower($k->status), ['tersedia', 'kosong']);
            })->count();

            $terisiCount = $total - $tersediaCount;
        ?>

        <div class="stats">
            <div class="stat">
                <div class="label">Total Kamar</div>
                <div class="value"><?php echo e($total); ?></div>
            </div>

            <div class="stat green">
                <div class="label">Tersedia</div>
                <div class="value"><?php echo e($tersediaCount); ?></div>
            </div>

            <div class="stat amber">
                <div class="label">Terisi</div>
                <div class="value"><?php echo e($terisiCount); ?></div>
            </div>
        </div>

        <div class="card">
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nomor Kamar</th>
                            <th>Nama Penghuni</th>
                            <th>Tipe Kamar</th>
                            <th>Harga</th>
                            <th>Fasilitas</th>
                            <th>Status</th>
                            <th>Keterangan</th>

                            
                            <?php if(auth()->user()->role === 'admin'): ?>
                                <th>Aksi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $kamars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kamar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td class="room-number"><?php echo e($kamar->nomor_kamar); ?></td>
                                <td><?php echo e($kamar->nama_penghuni ?? '-'); ?></td>
                                <td><?php echo e($kamar->tipe_kamar); ?></td>
                                <td>Rp <?php echo e(number_format($kamar->harga, 0, ',', '.')); ?></td>
                                <td><?php echo e($kamar->fasilitas ?? '-'); ?></td>

                                <td>
                                    <?php
                                        $tersedia = in_array(strtolower($kamar->status), ['tersedia', 'kosong']);
                                    ?>

                                    <span class="badge <?php echo e($tersedia ? 'badge-success' : 'badge-warning'); ?>">
                                        <?php echo e($kamar->status); ?>

                                    </span>
                                </td>

                                <td><?php echo e($kamar->keterangan ?? '-'); ?></td>

                                
                                <?php if(auth()->user()->role === 'admin'): ?>
                                    <td>
                                        <div class="aksi">
                                            <a href="<?php echo e(route('kamars.edit', $kamar->id)); ?>"
                                               class="edit-button">
                                                Edit
                                            </a>

                                            <form action="<?php echo e(route('kamars.destroy', $kamar->id)); ?>"
                                                  method="POST"
                                                  onsubmit="return confirm('Yakin ingin menghapus data kamar ini?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                                <button type="submit" class="delete-button">
                                                    Hapus
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                <?php endif; ?>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="<?php echo e(auth()->user()->role === 'admin' ? 9 : 8); ?>"
                                    class="empty">
                                    Belum ada data kamar yang tersedia.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

</body>
</html>
<?php /**PATH C:\Users\TIARA\nama-project\resources\views/kamars/index.blade.php ENDPATH**/ ?>